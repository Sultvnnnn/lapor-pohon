"use client";

import { motion } from "framer-motion";
import {
  Camera,
  Cpu,
  Buildings,
  Recycle,
  ArrowRight,
  Sparkle,
} from "@phosphor-icons/react";

export const WorkflowSection = () => {
  const steps = [
    {
      number: "01",
      icon: Camera,
      title: "Warga Melaporkan Pohon",
      description:
        "Warga mengunggah foto pohon di lingkungan sekitar beserta deskripsi dan koordinat lokasi terkini.",
    },
    {
      number: "02",
      icon: Cpu,
      title: "Analisis AI Instant",
      description:
        "Mesin YOLOv8 memproses foto, memetakan bounding box, menghitung volume kanopi, biomassa, dan skor risiko.",
    },
    {
      number: "03",
      icon: Buildings,
      title: "Tindakan Dinas Terarah",
      description:
        "Dinas Pertamanan memverifikasi data AI dan menjadwalkan tindakan pemangkasan/penebangan yang prioritas.",
    },
    {
      number: "04",
      icon: Recycle,
      title: "Pemanfaatan UMKM & Replant",
      description:
        "Kayu disalurkan ke UMKM pengrajin kayu/biomassa, dan bibit pohon baru ditanam untuk menjaga kelestarian.",
    },
  ];

  return (
    <section id="alur" className="py-20 bg-gradient-to-b from-[#F4F1EA] to-[#F9F8F3] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C87443]/10 text-[#C87443] text-xs font-semibold">
            <Sparkle size={14} weight="fill" />
            <span>Alur Kerja Sirkular</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#19382B] tracking-tight">
            Bagaimana LaporPohon Bekerja?
          </h2>
          <p className="text-base text-[#19382B]/75 leading-relaxed">
            Empat langkah sederhana dari pelaporan warga hingga dampak ekologis sirkular berkelanjutan.
          </p>
        </div>

        {/* Workflow Grid (Mobile-First 1 Column -> 2 Columns -> 4 Columns) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.12 }}
                className="relative rounded-3xl bg-white p-6 border border-[#19382B]/10 shadow-lg shadow-[#19382B]/5 flex flex-col justify-between group hover:border-[#19382B]/30 transition-all duration-300"
              >
                <div>
                  {/* Step Number & Icon */}
                  <div className="flex items-center justify-between mb-5">
                    <span className="text-3xl font-black text-[#19382B]/20 group-hover:text-[#C87443] transition-colors">
                      {step.number}
                    </span>
                    <div className="w-11 h-11 rounded-2xl bg-[#19382B] text-white flex items-center justify-center shadow-md">
                      <Icon size={22} weight="fill" />
                    </div>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-lg font-bold text-[#19382B] mb-2 leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-xs text-[#19382B]/75 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Connecting Arrow for Desktop */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-[#19382B]/20">
                    <ArrowRight size={20} weight="bold" />
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
