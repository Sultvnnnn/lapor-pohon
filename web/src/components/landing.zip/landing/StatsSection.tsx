"use client";

import { motion } from "framer-motion";
import { Tree, Barbell, Lightning, Plant } from "@phosphor-icons/react";

export const StatsSection = () => {
  const stats = [
    {
      icon: Tree,
      value: "1,240+",
      label: "Laporan Pohon",
      subtext: "Teranalisis presisi oleh AI YOLOv8",
      color: "text-[#19382B]",
      bgColor: "bg-[#19382B]/10",
    },
    {
      icon: Barbell,
      value: "18.5 Ton",
      label: "Biomassa Terhitung",
      subtext: "Siap dimanfaatkan UMKM pengrajin",
      color: "text-[#C87443]",
      bgColor: "bg-[#C87443]/10",
    },
    {
      icon: Lightning,
      value: "< 2 Jam",
      label: "Respon Risiko",
      subtext: "Mitigasi bahaya pohon tumbang",
      color: "text-amber-700",
      bgColor: "bg-amber-500/10",
    },
    {
      icon: Plant,
      value: "2,480+",
      label: "Bibit Replant",
      subtext: "Komitmen kelestarian lingkungan",
      color: "text-emerald-700",
      bgColor: "bg-emerald-500/10",
    },
  ];

  return (
    <section className="py-12 bg-[#19382B] text-white rounded-3xl mx-4 sm:mx-6 lg:mx-8 shadow-2xl overflow-hidden relative">
      {/* Background Accent Lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#3E6B54_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="p-5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                    <Icon size={24} className={stat.color} weight="fill" />
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300/60">
                    Live Metric
                  </span>
                </div>

                <div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-1">
                    {stat.value}
                  </h3>
                  <p className="text-sm font-semibold text-emerald-200">{stat.label}</p>
                  <p className="text-xs text-emerald-100/70 mt-1">{stat.subtext}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
