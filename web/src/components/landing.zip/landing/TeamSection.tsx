"use client";

import { motion } from "framer-motion";
import { User, Student, GraduationCap, LinkedinLogo, GithubLogo } from "@phosphor-icons/react";

export const TeamSection = () => {
  const team = [
    {
      name: "Mayang Putri Mutiara",
      role: "Teknologi Informasi",
      institution: "Institut Teknologi Tangerang Selatan",
      initials: "MP",
    },
    {
      name: "Sultan Abdul Fatah",
      role: "Informatika",
      institution: "Institut Teknologi Tangerang Selatan",
      initials: "SF",
    },
    {
      name: "Sahrul Solihin",
      role: "Informatika",
      institution: "Institut Teknologi Tangerang Selatan",
      initials: "SS",
    },
  ];

  return (
    <section id="tim" className="py-20 bg-[#19382B] text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 text-emerald-300 text-xs font-semibold">
            <GraduationCap size={16} weight="fill" />
            <span>Tim Pengembang (MVP DSDC ANFORCOM 2026)</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Di Balik LaporPohon
          </h2>
          <p className="text-sm sm:text-base text-emerald-100/75 leading-relaxed">
            Inovasi mahasiswa Institut Teknologi Tangerang Selatan (ITTS) untuk mendukung ekosistem perkotaan sirkular berbasis AI.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {team.map((member, index) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              whileHover={{ y: -6 }}
              className="rounded-3xl bg-white/5 border border-white/10 p-7 backdrop-blur-md flex flex-col items-center text-center group hover:bg-white/10 transition-all duration-300"
            >
              {/* Avatar Circle */}
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#C87443] to-amber-400 text-[#19382B] font-extrabold text-xl flex items-center justify-center shadow-lg shadow-black/20 mb-5 group-hover:scale-105 transition-transform duration-300">
                {member.initials}
              </div>

              {/* Name & Role */}
              <h3 className="text-lg font-bold text-white mb-1">
                {member.name}
              </h3>
              <p className="text-xs font-semibold text-[#C87443] mb-2">
                {member.role}
              </p>

              {/* Institution */}
              <div className="flex items-center gap-1.5 text-xs text-emerald-200/70 font-medium">
                <Student size={14} weight="fill" />
                <span>{member.institution}</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
