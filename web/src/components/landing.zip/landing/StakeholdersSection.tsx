"use client";

import { motion } from "framer-motion";
import { User, Buildings, Storefront, CheckCircle } from "@phosphor-icons/react";

export const StakeholdersSection = () => {
  const roles = [
    {
      role: "Warga Pelapor",
      title: "Untuk Masyarakat Umum",
      icon: User,
      bgColor: "bg-emerald-50",
      borderColor: "border-emerald-200",
      badgeColor: "bg-emerald-100 text-emerald-800",
      description:
        "Partisipasi aktif warga dalam memantau dan melaporkan pohon yang berpotensi membahayakan keselamatan umum.",
      benefits: [
        "Formulir laporan praktis via HP",
        "Notifikasi status penanganan otomatis",
        "Berkontribusi pada penghijauan kota",
      ],
    },
    {
      role: "Dinas Pertamanan",
      title: "Untuk Instansi Pemerintah",
      icon: Buildings,
      bgColor: "bg-[#19382B]/5",
      borderColor: "border-[#19382B]/15",
      badgeColor: "bg-[#19382B] text-white",
      description:
        "Dashboard manajemen risiko berbasis data AI untuk penentuan skala prioritas pemangkasan dan audit hutang tanam.",
      benefits: [
        "Peta lokasi risiko hazard terverifikasi",
        "Penjadwalan eksekusi lapangan presisi",
        "Audit transparansi replant debt",
      ],
    },
    {
      role: "UMKM Woodcraft",
      title: "Untuk Pelaku Usaha Kayu",
      icon: Storefront,
      bgColor: "bg-[#C87443]/10",
      borderColor: "border-[#C87443]/20",
      badgeColor: "bg-[#C87443] text-white",
      description:
        "Akses ke pasokan bahan baku kayu sirkular hasil pemangkasan untuk diolah menjadi produk bernilai tambah.",
      benefits: [
        "Katalog estimasi volume & biomassa",
        "Pasokan kayu legal & ramah lingkungan",
        "Mendorong ekonomi sirkular lokal",
      ],
    },
  ];

  return (
    <section id="ekosistem" className="py-20 bg-[#F9F8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#19382B] tracking-tight">
            Sinergi Tiga Pilar Ekosistem
          </h2>
          <p className="text-base text-[#19382B]/75 leading-relaxed">
            LaporPohon menghubungkan masyarakat, pemerintah kota, dan pelaku usaha sirkular dalam satu siklus yang saling menguntungkan.
          </p>
        </div>

        {/* Stakeholder Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {roles.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.role}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className={`rounded-3xl p-7 border ${item.borderColor} ${item.bgColor} shadow-lg shadow-[#19382B]/5 flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-2xl bg-white text-[#19382B] shadow-md flex items-center justify-center">
                      <Icon size={24} weight="fill" />
                    </div>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full ${item.badgeColor}`}>
                      {item.role}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-[#19382B] mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#19382B]/80 leading-relaxed mb-6">
                    {item.description}
                  </p>

                  <div className="space-y-2.5 pt-4 border-t border-[#19382B]/10">
                    {item.benefits.map((b) => (
                      <div key={b} className="flex items-center gap-2 text-xs font-semibold text-[#19382B]">
                        <CheckCircle size={15} className="text-[#C87443]" weight="fill" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
