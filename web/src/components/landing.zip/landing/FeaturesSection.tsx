"use client";

import { motion } from "framer-motion";
import {
  Scan,
  Scales,
  Plant,
  CheckCircle,
  ArrowRight,
  Sparkle,
  ChartPieSlice,
  ShieldCheck,
} from "@phosphor-icons/react";

export const FeaturesSection = () => {
  const features = [
    {
      id: "ai-hazard",
      tag: "Mesin Inferensi YOLOv8",
      title: "Deteksi Otomatis Risiko & Hazard Pohon",
      description:
        "Algoritma visi komputer menganalisis foto pelaporan warga untuk mendeteksi posisi pohon, bounding box presisi, serta menilai tingkat risiko potensi tumbang secara real-time.",
      icon: Scan,
      badgeColor: "bg-red-50 text-red-700 border-red-200",
      accentColor: "border-red-500/20 hover:border-red-500/40",
      points: [
        "Estimasi tingkat risiko (Rendah, Sedang, Tinggi)",
        "Skor confidence & koordinat bounding box",
        "Peta lokasi interaktif untuk verifikasi dinas",
      ],
    },
    {
      id: "biomass-calc",
      tag: "Persamaan Alometrik Ekologis",
      title: "Estimasi Volume Kanopi & Biomassa Kayu",
      description:
        "Menghitung potensi kayu yang dapat dipangkas menggunakan rumus alometrik Chave et al. (2005) untuk membuka peluang ekonomi sirkular bagi UMKM pengrajin kayu lokal.",
      icon: Scales,
      badgeColor: "bg-amber-50 text-amber-800 border-amber-200",
      accentColor: "border-[#C87443]/20 hover:border-[#C87443]/40",
      points: [
        "Estimasi diameter batang (DBH) dari lebar kanopi",
        "Volume kanopi setengah bola (m³) & biomassa (kg)",
        "Katalog pasokan kayu daur ulang untuk UMKM",
      ],
    },
    {
      id: "replant-debt",
      tag: "Sirkularitas Lingkungan",
      title: "Pencatatan Hutang Tanam (Replant Debt)",
      description:
        "Sistem mencatat komitmen penanaman pohon baru untuk setiap pohon yang dipangkas atau ditebang, menjamin jumlah pohon kota tidak pernah berkurang.",
      icon: Plant,
      badgeColor: "bg-emerald-50 text-emerald-800 border-emerald-200",
      accentColor: "border-emerald-500/20 hover:border-emerald-500/40",
      points: [
        "Audit rasio penanaman kembali (1:2 atau 1:3)",
        "Laporan transparansi kelestarian lingkungan",
        "Integrasi partisipasi warga & komunitas hijau",
      ],
    },
  ];

  return (
    <section id="fitur" className="py-20 bg-[#F9F8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#19382B]/10 text-[#19382B] text-xs font-semibold">
            <Sparkle size={14} weight="fill" className="text-[#C87443]" />
            <span>Teknologi & Fitur Utama</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#19382B] tracking-tight">
            Tiga Pilar Utama Ekosistem LaporPohon
          </h2>
          <p className="text-base text-[#19382B]/75 leading-relaxed">
            Menghubungkan kecerdasan buatan, keberlanjutan lingkungan, dan nilai ekonomi sirkular masyarakat dalam satu platform terpadu.
          </p>
        </div>

        {/* Feature Cards Grid (Mobile-First) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {features.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                whileHover={{ y: -6 }}
                className={`rounded-3xl bg-white p-7 sm:p-8 border ${item.accentColor} shadow-xl shadow-[#19382B]/5 transition-all duration-300 flex flex-col justify-between group`}
              >
                <div>
                  {/* Top Tag & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-[#19382B]/5 text-[#19382B] flex items-center justify-center group-hover:bg-[#19382B] group-hover:text-white transition-colors duration-300">
                      <Icon size={26} weight="fill" />
                    </div>
                    <span
                      className={`text-[11px] font-bold px-3 py-1 rounded-full border ${item.badgeColor}`}
                    >
                      {item.tag}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-bold text-[#19382B] mb-3 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#19382B]/75 leading-relaxed mb-6">
                    {item.description}
                  </p>

                  {/* Bullet Points */}
                  <div className="space-y-2.5 pt-4 border-t border-[#19382B]/10">
                    {item.points.map((point) => (
                      <div key={point} className="flex items-start gap-2.5 text-xs text-[#19382B]/85 font-medium">
                        <CheckCircle size={16} className="text-[#C87443] shrink-0 mt-0.5" weight="fill" />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Action Link */}
                <div className="pt-6 mt-6 border-t border-[#19382B]/5 flex items-center justify-between">
                  <span className="text-xs font-bold text-[#19382B]">Pelajari Sistem</span>
                  <div className="w-8 h-8 rounded-full bg-[#19382B]/5 text-[#19382B] flex items-center justify-center group-hover:bg-[#C87443] group-hover:text-white transition-all">
                    <ArrowRight size={14} weight="bold" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
