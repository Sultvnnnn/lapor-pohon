"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Tree,
  ShieldWarning,
  Plant,
  Kanban,
  ArrowRight,
  Sparkle,
  CheckCircle,
  Cpu,
} from "@phosphor-icons/react";

export const HeroSection = () => {
  return (
    <section id="tentang" className="relative overflow-hidden pt-8 pb-16 lg:pt-16 lg:pb-24">
      {/* Organic Background Gradients & Accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-[#3E6B54]/15 via-[#C87443]/10 to-transparent blur-3xl -z-10 pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left / Top Text Content (Mobile-First) */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="lg:col-span-7 flex flex-col items-start text-left space-y-6"
          >
            {/* Pill Tagline */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#19382B]/10 border border-[#19382B]/20 text-[#19382B] text-xs font-semibold backdrop-blur-sm">
              <span className="flex h-2 w-2 rounded-full bg-[#C87443] animate-pulse" />
              <span>MVP DSDC ANFORCOM 2026</span>
              <span className="text-[#19382B]/30">•</span>
              <span className="text-[#C87443] flex items-center gap-1 font-bold">
                <Cpu size={14} weight="bold" /> AI Urban Forestry
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-[#19382B] leading-[1.15]">
              Kelola Ekosistem Pohon Perkotaan Secara{" "}
              <span className="relative inline-block text-[#C87443]">
                Sirkular
                <svg
                  className="absolute -bottom-2 left-0 w-full h-3 text-[#C87443]/40"
                  viewBox="0 0 100 20"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M0 15 Q 50 0 100 15"
                    stroke="currentColor"
                    strokeWidth="4"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>{" "}
              Berbasis AI
            </h1>

            {/* Subheadline */}
            <p className="text-sm sm:text-base md:text-lg text-[#19382B]/80 font-normal leading-relaxed max-w-2xl">
              Platform cerdas yang mendeteksi **risiko bahaya pohon** menggunakan AI YOLOv8, mengkalkulasi **volume kayu biomassa** untuk UMKM pengrajin, serta mencatat **hutang tanam** demi kelestarian hijau perkotaan.
            </p>

            {/* CTA Buttons */}
            <div className="w-full sm:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <Link
                href="/register"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-bold text-white bg-[#19382B] hover:bg-[#234A39] rounded-2xl shadow-xl shadow-[#19382B]/25 hover:shadow-2xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
              >
                <Tree size={20} weight="fill" />
                Laporkan Pohon Sekarang
                <ArrowRight size={18} weight="bold" />
              </Link>
              <a
                href="#fitur"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#19382B] bg-[#19382B]/5 hover:bg-[#19382B]/10 rounded-2xl border border-[#19382B]/15 transition-all duration-200"
              >
                Jelajahi Teknologi AI
              </a>
            </div>

            {/* Trust Micro Indicators */}
            <div className="pt-4 border-t border-[#19382B]/10 w-full grid grid-cols-3 gap-2 text-left">
              <div className="flex flex-col">
                <span className="text-lg sm:text-2xl font-extrabold text-[#19382B]">98.4%</span>
                <span className="text-[11px] sm:text-xs text-[#19382B]/70 font-medium">Akurasi YOLOv8</span>
              </div>
              <div className="flex flex-col border-l border-[#19382B]/10 pl-3">
                <span className="text-lg sm:text-2xl font-extrabold text-[#C87443]">100%</span>
                <span className="text-[11px] sm:text-xs text-[#19382B]/70 font-medium">Sirkular Biomassa</span>
              </div>
              <div className="flex flex-col border-l border-[#19382B]/10 pl-3">
                <span className="text-lg sm:text-2xl font-extrabold text-[#19382B]">Real-time</span>
                <span className="text-[11px] sm:text-xs text-[#19382B]/70 font-medium">Monitoring Pohon</span>
              </div>
            </div>
          </motion.div>

          {/* Right / Bottom Interactive Mockup Card (Mobile-First) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
            className="lg:col-span-5 relative"
          >
            {/* Card Frame with Glassmorphism & Eco Borders */}
            <div className="relative rounded-3xl bg-gradient-to-b from-white to-[#F4F1EA] p-5 sm:p-6 border border-[#19382B]/15 shadow-2xl shadow-[#19382B]/10">
              
              {/* Header Badge in Mockup */}
              <div className="flex items-center justify-between pb-4 border-b border-[#19382B]/10 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-amber-400" />
                  <div className="w-3 h-3 rounded-full bg-emerald-400" />
                  <span className="text-xs font-bold text-[#19382B] ml-2">Pratinjau AI Inferensi</span>
                </div>
                <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-red-100 text-red-700 border border-red-200">
                  Risiko Tinggi (0.82)
                </span>
              </div>

              {/* Mock Image Representation */}
              <div className="relative rounded-2xl overflow-hidden bg-emerald-950 aspect-[4/3] flex items-center justify-center shadow-inner group">
                {/* Simulated Bounding Box Overlay */}
                <div className="absolute inset-4 border-2 border-dashed border-amber-400 rounded-xl bg-amber-400/10 flex flex-col justify-between p-3 animate-pulse">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold bg-amber-500 text-white px-2 py-0.5 rounded shadow">
                      Tree Box #1 (Conf: 94%)
                    </span>
                    <ShieldWarning size={18} className="text-amber-400" weight="fill" />
                  </div>
                  <div className="text-[10px] text-amber-200 font-mono bg-black/60 px-2 py-1 rounded self-start backdrop-blur-sm">
                    Lat: -6.1754 | Long: 106.8272
                  </div>
                </div>

                {/* Background Tree Illustration Graphic */}
                <div className="flex flex-col items-center justify-center text-center p-6 text-emerald-200 opacity-60">
                  <Tree size={72} weight="duotone" className="text-emerald-400 mb-2" />
                  <span className="text-xs font-semibold text-emerald-100">Foto Pohon Terdeteksi</span>
                </div>
              </div>

              {/* Metrics Grid Below Mockup */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="p-3 rounded-2xl bg-[#19382B]/5 border border-[#19382B]/10">
                  <span className="text-[11px] text-[#19382B]/70 font-medium block">Volume Kanopi</span>
                  <span className="text-base font-bold text-[#19382B]">42.50 m³</span>
                </div>
                <div className="p-3 rounded-2xl bg-[#C87443]/10 border border-[#C87443]/20">
                  <span className="text-[11px] text-[#C87443] font-medium block">Estimasi Biomassa</span>
                  <span className="text-base font-bold text-[#C87443]">148.20 kg</span>
                </div>
              </div>

              {/* Replant Debt Footer Item */}
              <div className="mt-3 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Plant size={20} className="text-emerald-700" weight="fill" />
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-emerald-900">Hutang Tanam (Replant)</span>
                    <span className="text-[10px] text-emerald-700">Wajib tanam +2 bibit pengganti</span>
                  </div>
                </div>
                <CheckCircle size={18} className="text-emerald-600" weight="fill" />
              </div>

            </div>

            {/* Floating Organic Micro Card Animation */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-4 sm:-left-6 bg-white p-3.5 rounded-2xl shadow-xl border border-[#19382B]/15 flex items-center gap-3 backdrop-blur-md"
            >
              <div className="w-9 h-9 rounded-xl bg-[#C87443]/15 text-[#C87443] flex items-center justify-center font-bold">
                <Kanban size={20} weight="fill" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-[#19382B]">Katalog UMKM Woodcraft</span>
                <span className="text-[10px] text-[#19382B]/70">Potensi Bahan Baku Terbuka</span>
              </div>
            </motion.div>

          </motion.div>

        </div>
      </div>
    </section>
  );
};
