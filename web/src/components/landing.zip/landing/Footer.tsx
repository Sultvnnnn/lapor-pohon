"use client";

import Link from "next/link";
import { Tree, Sparkle, Heart } from "@phosphor-icons/react";

export const Footer = () => {
  return (
    <footer className="bg-[#142E23] text-white pt-16 pb-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-[#C87443] text-white flex items-center justify-center shadow-md">
                <Tree size={24} weight="fill" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg text-white">LaporPohon</span>
                <span className="text-[10px] font-medium text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                  <Sparkle size={10} weight="fill" /> Urban Forestry AI
                </span>
              </div>
            </Link>

            <p className="text-xs text-emerald-100/70 leading-relaxed max-w-sm">
              Platform sirkular ekosistem pohon perkotaan yang memanfaatkan kecerdasan buatan (YOLOv8) untuk memitigasi bahaya pohon, menghitung biomassa kayu UMKM, dan mencatat hutang tanam.
            </p>
          </div>

          {/* Nav Col 1 */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-[#C87443] uppercase tracking-wider">
              Navigasi Halaman
            </h4>
            <ul className="space-y-2 text-xs text-emerald-100/80 font-medium">
              <li>
                <a href="#tentang" className="hover:text-white transition-colors">Tentang LaporPohon</a>
              </li>
              <li>
                <a href="#fitur" className="hover:text-white transition-colors">Fitur AI YOLOv8</a>
              </li>
              <li>
                <a href="#alur" className="hover:text-white transition-colors">Alur Kerja Sirkular</a>
              </li>
              <li>
                <a href="#ekosistem" className="hover:text-white transition-colors">Tiga Pilar Peran</a>
              </li>
              <li>
                <a href="#tim" className="hover:text-white transition-colors">Tim Pengembang ITTS</a>
              </li>
            </ul>
          </div>

          {/* Action Col 2 */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-xs font-bold text-[#C87443] uppercase tracking-wider">
              Akses Pengguna
            </h4>
            <div className="flex flex-col gap-2.5">
              <Link
                href="/login"
                className="w-full py-2.5 px-4 text-center text-xs font-semibold bg-white/10 hover:bg-white/20 rounded-xl transition-all"
              >
                Masuk ke Akun Anda
              </Link>
              <Link
                href="/register"
                className="w-full py-2.5 px-4 text-center text-xs font-bold bg-[#C87443] hover:bg-[#b06338] text-white rounded-xl shadow-lg transition-all"
              >
                Daftar Pelapor Warga / UMKM
              </Link>
            </div>
          </div>

        </div>

        {/* Bottom Rights */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-emerald-200/50 gap-4">
          <p>© 2026 LaporPohon (MVP DSDC ANFORCOM 2026). Hak Cipta Dilindungi.</p>
          <p className="flex items-center gap-1">
            Dikembangkan dengan <Heart size={14} className="text-red-400" weight="fill" /> oleh Tim ITTS
          </p>
        </div>

      </div>
    </footer>
  );
};
