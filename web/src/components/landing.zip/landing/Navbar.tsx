"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Tree,
  List,
  X,
  SignIn,
  UserPlus,
  ShieldCheck,
  Sparkle,
  ArrowRight,
} from "@phosphor-icons/react";

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: "Tentang", href: "#tentang" },
    { name: "Fitur AI", href: "#fitur" },
    { name: "Alur Kerja", href: "#alur" },
    { name: "Ekosistem", href: "#ekosistem" },
    { name: "Tim", href: "#tim" },
  ];

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-[#F9F8F3]/85 border-b border-[#19382B]/10 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-2xl bg-[#19382B] text-amber-400 flex items-center justify-center shadow-md shadow-[#19382B]/20 group-hover:scale-105 transition-transform duration-300">
              <Tree size={24} weight="fill" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-tight tracking-tight text-[#19382B]">
                LaporPohon
              </span>
              <span className="text-[10px] font-medium text-[#C87443] tracking-wider uppercase flex items-center gap-1">
                <Sparkle size={10} weight="fill" /> Sirkular AI
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#19382B]/5 p-1.5 rounded-full border border-[#19382B]/10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-4 py-2 text-xs font-semibold text-[#19382B]/80 hover:text-[#19382B] hover:bg-white/80 rounded-full transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Desktop Action Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/login"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#19382B] hover:bg-[#19382B]/10 rounded-full transition-all duration-200"
            >
              <SignIn size={16} weight="bold" />
              Masuk
            </Link>
            <Link
              href="/register"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#19382B] hover:bg-[#234A39] rounded-full shadow-lg shadow-[#19382B]/20 hover:shadow-xl hover:scale-[1.02] active:scale-95 transition-all duration-200"
            >
              <UserPlus size={16} weight="bold" />
              Daftar Akun
            </Link>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
            className="md:hidden p-2.5 rounded-2xl bg-[#19382B]/5 text-[#19382B] hover:bg-[#19382B]/10 focus:outline-none transition-colors"
          >
            {isOpen ? <X size={22} weight="bold" /> : <List size={22} weight="bold" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="md:hidden border-b border-[#19382B]/10 bg-[#F9F8F3] overflow-hidden"
          >
            <div className="px-4 pt-3 pb-6 space-y-4">
              <div className="flex flex-col space-y-1">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="px-4 py-3 text-sm font-semibold text-[#19382B] hover:bg-[#19382B]/5 rounded-xl transition-colors flex items-center justify-between"
                  >
                    {link.name}
                    <ArrowRight size={14} className="text-[#C87443]" />
                  </a>
                ))}
              </div>

              <div className="pt-2 border-t border-[#19382B]/10 flex flex-col gap-2.5">
                <Link
                  href="/login"
                  onClick={() => setIsOpen(false)}
                  className="w-full py-3 text-center text-sm font-semibold text-[#19382B] bg-[#19382B]/5 hover:bg-[#19382B]/10 rounded-2xl transition-colors flex items-center justify-center gap-2"
                >
                  <SignIn size={18} weight="bold" />
                  Masuk Akun
                </Link>
                <Link
                  href="/register"
                  onClick={() => setIsOpen(false)}
                  className="w-full py-3 text-center text-sm font-semibold text-white bg-[#19382B] hover:bg-[#234A39] rounded-2xl shadow-md shadow-[#19382B]/20 transition-all flex items-center justify-center gap-2"
                >
                  <UserPlus size={18} weight="bold" />
                  Daftar Sekarang
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
